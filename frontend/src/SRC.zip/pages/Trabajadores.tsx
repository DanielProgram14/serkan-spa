import { Typography } from '@mui/material';
const Trabajadores = () => <Typography variant="h4">Gestión de Trabajadores</Typography>;
export default Trabajadores;