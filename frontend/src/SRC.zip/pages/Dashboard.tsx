import { Grid, Paper, Typography, Box } from '@mui/material';
import { WarningAmber, EventBusy, Assignment } from '@mui/icons-material';

const Dashboard = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Panel de Control
      </Typography>
      
      {/* Grid de Resumen (KPIs) */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {/* KPI: Tareas Vencidas */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, display: 'flex', flexDirection: 'column', borderLeft: '6px solid #d32f2f' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography color="textSecondary">Tareas Vencidas</Typography>
              <WarningAmber color="error" />
            </Box>
            <Typography variant="h3" fontWeight="bold">3</Typography>
            <Typography variant="caption" color="error">Requieren atención inmediata</Typography>
          </Paper>
        </Grid>

        {/* KPI: Documentos por Vencer */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, display: 'flex', flexDirection: 'column', borderLeft: '6px solid #f57c00' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography color="textSecondary">Docs. por Vencer</Typography>
              <EventBusy color="warning" />
            </Box>
            <Typography variant="h3" fontWeight="bold">5</Typography>
            <Typography variant="caption" color="textSecondary">Próximos 30 días</Typography>
          </Paper>
        </Grid>

        {/* KPI: Tareas Asignadas */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, display: 'flex', flexDirection: 'column', borderLeft: '6px solid #1976d2' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography color="textSecondary">Mis Tareas Activas</Typography>
              <Assignment color="primary" />
            </Box>
            <Typography variant="h3" fontWeight="bold">12</Typography>
            <Typography variant="caption" color="textSecondary">En progreso</Typography>
          </Paper>
        </Grid>
      </Grid>

      <Typography variant="h6" gutterBottom>Actividad Reciente</Typography>
      <Paper sx={{ p: 2 }}>
        <Typography variant="body2" color="textSecondary">
          No hay actividad reciente para mostrar.
        </Typography>
      </Paper>
    </Box>
  );
};

export default Dashboard;