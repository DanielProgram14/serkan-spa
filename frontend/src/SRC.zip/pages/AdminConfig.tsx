import { Typography } from '@mui/material';
const AdminConfig = () => <Typography variant="h4">Administración del Sistema</Typography>;
export default AdminConfig;