import { Typography } from '@mui/material';
const Tareas = () => <Typography variant="h4">Mis Tareas y Notas</Typography>;
export default Tareas;