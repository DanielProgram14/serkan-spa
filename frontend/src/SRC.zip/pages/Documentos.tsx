import { Typography } from '@mui/material';
const Documentos = () => <Typography variant="h4">Gestión Documental</Typography>;
export default Documentos;