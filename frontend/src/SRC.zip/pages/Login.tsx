import React, { useState } from 'react';
import { 
  Box, 
  Button, 
  Container, 
  TextField, 
  Typography, 
  Paper, 
  Alert, 
  CircularProgress,
  InputAdornment,
  IconButton
} from '@mui/material';
import { Visibility, VisibilityOff, LockOutlined, EmailOutlined } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
// import api from '../api/axios'; // Descomentar cuando conectemos el backend

const Login = () => {
  const navigate = useNavigate();
  
  // Estados para manejo del formulario
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    // Validación básica de frontend
    if (!email || !password) {
      setError("Por favor, ingresa tus credenciales completas.");
      setLoading(false);
      return;
    }

    try {
      // --- SIMULACIÓN DE CONEXIÓN AL BACKEND (TODO: Reemplazar con API real) ---
      // const response = await api.post('/auth/login/', { email, password });
      // localStorage.setItem('token', response.data.access);
      // localStorage.setItem('user', JSON.stringify(response.data.user));
      
      console.log("Intentando login con:", email);
      
      // Simular espera de red
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Redirigir al Dashboard tras éxito
      navigate('/dashboard');
      
    } catch (err) {
      setError("Credenciales inválidas o error de conexión.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box 
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#f0f2f5', // Fondo gris suave corporativo
        backgroundImage: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)' // Opción Dark Mode elegante
      }}
    >
      <Container maxWidth="xs">
        <Paper 
          elevation={10} 
          sx={{ 
            p: 4, 
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center',
            borderRadius: 3
          }}
        >
          {/* Logo / Branding */}
          <Box 
            sx={{ 
              mb: 3, 
              width: 60, 
              height: 60, 
              bgcolor: 'primary.main', 
              borderRadius: '50%', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center'
            }}
          >
            <LockOutlined sx={{ color: 'white', fontSize: 30 }} />
          </Box>

          <Typography component="h1" variant="h5" fontWeight="bold" color="primary">
            SERKAN SPA
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Sistema de Administración Interna
          </Typography>

          {/* Feedback de Error */}
          {error && (
            <Alert severity="error" sx={{ width: '100%', mb: 2 }}>
              {error}
            </Alert>
          )}

          {/* Formulario */}
          <Box component="form" onSubmit={handleLogin} noValidate sx={{ mt: 1, width: '100%' }}>
            <TextField
              margin="normal"
              required
              fullWidth
              id="email"
              label="Correo Corporativo"
              name="email"
              autoComplete="email"
              autoFocus
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <EmailOutlined color="action" />
                  </InputAdornment>
                ),
              }}
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="password"
              label="Contraseña"
              type={showPassword ? 'text' : 'password'}
              id="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />

            <Button
              type="submit"
              fullWidth
              variant="contained"
              size="large"
              disabled={loading}
              sx={{ mt: 3, mb: 2, py: 1.5, fontWeight: 'bold' }}
            >
              {loading ? <CircularProgress size={24} color="inherit" /> : 'INICIAR SESIÓN'}
            </Button>
            
            {/* Footer con datos reales según PDF  */}
            <Typography variant="caption" display="block" align="center" color="text.secondary" sx={{ mt: 4 }}>
              © 2026 SERKAN SPA - Innovación y Desarrollo
              <br />
              Baquedano 320, Oficina 239, Antofagasta
            </Typography>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
};

export default Login;