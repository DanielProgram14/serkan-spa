import { Box, Container } from '@mui/material';
import Navbar from './Navbar';
import { Outlet } from 'react-router-dom';

// Agregamos una prop temporal para simular el rol en todo el layout
const Layout = () => {
  // TODO: En el futuro, esto vendrá del Contexto de Autenticación (AuthContext)
  const userRol = 'ADMIN'; 

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', bgcolor: '#121212', color: 'white' }}>
      {/* Pasamos el rol explícitamente al Navbar */}
      <Navbar rol={userRol} /> 
      
      <Container component="main" sx={{ mt: 4, mb: 4, flex: 1 }}>
        <Outlet />
      </Container>
      
      <Box component="footer" sx={{ p: 2, textAlign: 'center', bgcolor: '#1e1e1e' }}>
        © 2026 SERKAN SPA - Innovación y Desarrollo
      </Box>
    </Box>
  );
};

export default Layout;