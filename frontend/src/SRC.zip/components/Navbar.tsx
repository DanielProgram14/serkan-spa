import { AppBar, Toolbar, Button, Typography, Box } from '@mui/material';
import { Link } from 'react-router-dom';

export type Rol = 'ADMIN' | 'RRHH' | 'SUPERVISOR' | 'TRABAJADOR';

const Navbar = ({ rol = 'ADMIN' }: { rol?: Rol }) => {
  return (
    <AppBar position="static" sx={{ backgroundColor: '#1e293b' }}>
      <Toolbar>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: 'bold' }}>
          SERKAN SPA
        </Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button color="inherit" component={Link} to="/dashboard">Dashboard</Button>
          
          {/* Lógica de visualización de botones según el Rol */}
          {['ADMIN', 'RRHH'].includes(rol) && (
            <>
              <Button color="inherit" component={Link} to="/trabajadores">Trabajadores</Button>
              <Button color="inherit" component={Link} to="/documentos">Documentos</Button>
            </>
          )}

          <Button color="inherit" component={Link} to="/tareas">Tareas</Button>

          {rol === 'ADMIN' && (
             <Button color="inherit" component={Link} to="/administracion">Admin</Button>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;