
// ¡IMPORTANTE! Debe decir "export type", no solo "type"
export type Rol = 'ADMIN' | 'RRHH' | 'SUPERVISOR' | 'TRABAJADOR';

export interface Usuario {
  email: string;
  rol: Rol;
  trabajador_rut?: string;
}

export interface Trabajador {
  rut: string;
  nombres: string;
  apellidos: string;
  area: string;
  cargo: string;
  estado: 'ACTIVO' | 'INACTIVO';
}

export interface Tarea {
  id: number;
  nombre: string;
  fecha_limite: string;
  urgencia: 'ALTA' | 'MEDIA' | 'BAJA';
  estado: 'PENDIENTE' | 'COMPLETADA' | 'CANCELADA';
}